package 팀과제.팀과제4;

public class Machine {

    void run(Capsule capsule){
        capsule.insert();
    }

    public void clean(){
        System.out.println("머신 청소를 시작합니다.");
    }
}
