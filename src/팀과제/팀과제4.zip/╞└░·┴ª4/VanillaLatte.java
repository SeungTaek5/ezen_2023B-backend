package 팀과제.팀과제4;

public class VanillaLatte implements Capsule{

    public void insert(){
        System.out.println("바닐라라떼가 추출됩니다.");
    }
}
