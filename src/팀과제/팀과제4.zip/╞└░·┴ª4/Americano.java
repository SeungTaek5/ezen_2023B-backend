package 팀과제.팀과제4;

public class Americano implements Capsule{

    public void insert(){
        System.out.println("아메리카노가 추출됩니다.");
    }
}
