package 팀과제.팀과제4;

public interface Capsule {

    void insert();
}
